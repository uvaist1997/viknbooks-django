{











    "OrderNo": "",





    "SalesDetails": [{"ActualProductTaxID": "",
                      "ActualUnitPrice": 25,

                      "Barcode": "",




                      "GST_Inclusive": false,

                      "HSNCode": null,


                      "ItemCode": "",

                      "MRP": "25.00000000",
                      "MinimumSalesPrice": 0,

                      "ProductCode": "116",



                      "PurchasePrice": 9.45,
                      "Qty": 1,

                      "SalesPrice": 25,
                      "SalesPrice1": "0E-8",
                      "SalesPrice2": "0E-8",
                      "SalesPrice3": "0E-8",
                      "SerialNo": "",
                      "SerialNos": [],
                      "Stock": -3,
                      "TAX1Amount": 0,
                      "TAX1Perc": 0,
                      "TAX2Amount": 0,
                      "TAX2Perc": 0,
                      "TAX3Amount": 0,
                      "TAX3Perc": 0,
                      "Tax1_Inclusive": false,
                      "Tax2_Inclusive": false,
                      "Tax3_Inclusive": false,
                      "TaxableAmount": 25,

                      "UnitList": [{"Action": "A",
                                    "AutoBarcode": 70315,
                                    "Barcode": "",
                                    "BatchCode": "0",

                                    "CreatedDate": "2021-11-24T09:20:02.424083",

                                    "DefaultUnit": true,
                                    "MRP": "25.00000000",
                                    "MultiFactor": "1.00000000",

                                    "PurchasePrice": 9.45,
                                    "SalesPrice": 25,
                                    "SalesPrice1": "0E-8",
                                    "SalesPrice2": "0E-8",
                                    "SalesPrice3": "0E-8",
                                    "UnitID": 2,
                                    "UnitInPurchase": false,
                                    "UnitInReports": false,
                                    "UnitInSales": false,
                                    "UnitName": "Pcs",
                                    "detailID": 0,
                                    "id": "53d5babc-7e6e-4229-b898-fef214fb1727"}],
                      "Action": "A",
                      "AutoBarcode": 70315,
                      "Barcode": "",
                      "BatchCode": "0",

                      "CreatedDate": "2021-11-24T09:20:02.424083",

                      "DefaultUnit": true,
                      "MRP": "25.00000000",
                      "MultiFactor": "1.00000000",

                      "PurchasePrice": 9.45,
                      "SalesPrice": 25,
                      "SalesPrice1": "0E-8",
                      "SalesPrice2": "0E-8",
                      "SalesPrice3": "0E-8",
                      "UnitID": 2,
                      "UnitInPurchase": false,
                      "UnitInReports": false,
                      "UnitInSales": false,
                      "UnitName": "Pcs",
                      "detailID": 0,
                      "id": "53d5babc-7e6e-4229-b898-fef214fb1727",
                      "UnitPrice": 25,
                      "Units": 316,

                      "VATPerc": 0,
                      "Vat_Inclusive": false,
                      "detailID": 0,
                      "is_Active": true,
                      "is_BatchSalesPrice": false,
                      "is_inclusive": false,
                      "is_kfc": false,
                      "unit": 1,
                      "unq_id": null
                      }],
    "SalesTax": 0,

    "ShippingCharge": 0,
    "ShowTotalTax": false,

    "TAX1Amount": 0,
    "TAX2Amount": 0,
    "TAX3Amount": 0,


    "TotalGrossAmt": 25,

    "TransactionTypeID": 1,
    "VATAmount": 0,
    "VAT_Treatment": "0",
    "VoucherNo": "SI37",
    "WarehouseID": 1,
    "is_salesOrder": false,
    "order_vouchers": [],
    "shipping_tax_amount": 0
}
